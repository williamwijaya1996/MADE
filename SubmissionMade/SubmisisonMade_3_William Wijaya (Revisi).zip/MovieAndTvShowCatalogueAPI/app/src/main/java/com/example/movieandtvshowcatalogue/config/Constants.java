package com.example.movieandtvshowcatalogue.config;

public class Constants {

    public static final String KEY_API ="8d92502d3142b9914025595b11a650ab";
    public static final String URL = "https://api.themoviedb.org/3/";
    public static final String START_IMAGE = "https://image.tmdb.org/t/p/w185";

}
